	<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
				<li style="color:Lime;" class="ts-label">Cyborg's Car Rental</li>
				<li ><a style="color:Yellow;"  href="dashboard.php"><i style="color:LightPink;" class="fa fa-dashboard"></i> Dashboard</a></li>
			
<li><a style="color:Coral;"  href="#"><i style="color:LightPink;" class="fa fa-tag"></i>Brands</a>
<ul>
<li><a style="color:Yellow;" href="create-brand.php">New Brand</a></li>
<li><a style="color:Coral;"  href="manage-brands.php">Manage Brands</a></li>
</ul>
</li>

<li><a style="color:Yellow;"  href="#"><i style="color:LightPink;" class="fa fa-sitemap"></i>Vehicles</a>
					<ul>
						<li><a style="color:Coral;" href="post-avehical.php">Post a new vehicle</a></li>
						<li><a style="color:Yellow;" href="manage-vehicles.php">Manage Vehicles</a></li>
					</ul>
				</li>
<li ><a style="color:Coral;"  href="reg-users.php"><i style="color:LightPink;" class="fa fa-users"></i> Registered Users</a></li>
				<li ><a style="color:Yellow;" href="manage-bookings.php"><i style="color:LightPink;" class="fa fa-car"></i>Manage Users Booking</a></li>
<li ><a style="color:Coral;" href="manage-rent-users.php"><i style="color:LightPink;" class="fa fa-unlock"></i>Manage Rent Users</a></li>
<li ><a style="color:Yellow;"  href="manage-trackings.php"><i style="color:LightPink;" class="fa fa-key"></i>Manage Purchasing Requests</a></li>
<li ><a style="color:Coral;" href="manage-sell-users.php"><i style="color:LightPink;" class="fa fa-road"></i>Manage Selling Requests</a></li>
<li ><a style="color:Yellow;"  href="payment.php"><i style="color:LightPink;" class="fa fa-credit-card"></i>Payments</a></li>
<li ><a style="color:Coral;" href="manage-conactusquery.php"><i style="color:LightPink;" class="fa fa-desktop""></i> Manage Contact Us Queries</a></li>
<li ><a style="color:Yellow;"  href="testimonials.php"><i style="color:LightPink;" class="fa fa-table"></i> Manage Feedback</a></li>
			<li style="color:LightPink;"><a style="color:Coral;" href="manage-pages.php"><i style="color:LightPink;" class="fa fa-files-o"></i> Manage Pages</a></li>
			<li style="color:LightPink;"><a style="color:Yellow;"  href="update-contactinfo.php"><i style="color:LightPink;" class="fa fa-comments"></i> Update Contact Information</a></li>

			</ul>
		</nav>