<div class="profile_nav">
          <ul>
              <li><a style="color:Gold;" href="update-password.php">Update Password</a></li>
            <li><a style="color:DarkOrange;" href="my-booking.php">My Car Bookings</a></li>
            <li><a style="color:Gold;" href="rent.php">Rent Your Car</a></li>
<li><a style="color:DarkOrange;" href="sell.php">Sell a Car</a></li>
<li><a style="color:Gold;" href="rent-bookings.php">My Rent Bookings</a></li>
<li><a style="color:DarkOrange;" href="trackings.php">My Purchasing Requests</a></li>
<li><a style="color:Gold;" href="sell-trackings.php">My Selling Requests</a></li>
            <li><a style="color:DarkOrange;" href="post-testimonial.php">Feedback</a></li>
               <li><a style="color:Gold;" href="my-testimonials.php">My Feedback</a></li>
            <li><a style="color:DarkOrange;" href="logout.php">Sign Out</a></li>
          </ul>
        </div>
      </div>